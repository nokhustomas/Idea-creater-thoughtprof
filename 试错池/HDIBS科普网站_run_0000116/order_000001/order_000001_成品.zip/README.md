# HDIBS 科学教育网站

## 启动说明
1. 安装依赖: pip install flask
2. 启动命令: python3 app.py
3. 访问地址: http://localhost:8765

## 密码说明
- 客户端密码: HDIBS435879
- 控制端密码: HDIBSwmllylzjc435879
