# Parametric L-Bracket

Generate STL and PNG from OpenSCAD model.

## Usage

