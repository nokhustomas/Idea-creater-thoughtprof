// Parametric L-bracket
// Parameters: L=60(长) W=30(宽) T=4(厚) H1=40 H2=40(臂高) D=5(孔径) N=2(孔数) R=3(圆角)

L = 60;   // 长
W = 30;   // 宽
T = 4;    // 厚
H1 = 40;  // 臂高1
H2 = 40;  // 臂高2
D = 5;    // 孔径
N = 2;    // 孔数
R = 3;    // 圆角

module rounded_cube(dim, r) {
    hull() {
        for (x = [r, dim[0]-r], y = [r, dim[1]-r], z = [r, dim[2]-r]) {
            translate([x, y, z])
                sphere(r=r);
        }
    }
}

module l_bracket() {
    difference() {
        // L-shape body
        union() {
            // Vertical arm
            translate([0, 0, 0])
                rounded_cube([T, W, H1], R);
            // Horizontal arm
            translate([0, 0, 0])
                rounded_cube([L, T, H2], R);
        }
        
        // Holes along the length
        spacing = (L - T - 2*R) / (N + 1);
        for (i = [1:N]) {
            x_pos = T + R + i * spacing;
            translate([x_pos, T/2, H1/2])
                rotate([90, 0, 0])
                    cylinder(d=D, h=W+2, center=true);
        }
    }
}

l_bracket();
