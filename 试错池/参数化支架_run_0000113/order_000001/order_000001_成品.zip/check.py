#!/usr/bin/env python3
import sys
import json
import os
import numpy as np

try:
    from stl import mesh
except ImportError:
    # Fallback without numpy-stl
    import struct

    def read_stl_fast(filepath):
        with open(filepath, 'rb') as f:
            header = f.read(80)
            num_triangles = struct.unpack('<I', f.read(4))[0]
            vertices = []
            for _ in range(num_triangles):
                f.read(12)  # normal
                v1 = struct.unpack('<fff', f.read(12))
                v2 = struct.unpack('<fff', f.read(12))
                v3 = struct.unpack('<fff', f.read(12))
                vertices.extend([v1, v2, v3])
                f.read(2)  # attribute
            return np.array(vertices)

    def compute_volume(vertices):
        volume = 0
        for i in range(0, len(vertices), 3):
            v1, v2, v3 = vertices[i], vertices[i+1], vertices[i+2]
            v = np.cross(v1, v2)
            volume += np.dot(v, v3)
        return abs(volume) / 6.0

    def get_bbox(vertices):
        all_coords = vertices.reshape(-1, 3)
        return {
            'x': (all_coords[:, 0].min(), all_coords[:, 0].max()),
            'y': (all_coords[:, 1].min(), all_coords[:, 1].max()),
            'z': (all_coords[:, 2].min(), all_coords[:, 2].max())
        }

    def analyze_stl(filepath):
        vertices = read_stl_fast(filepath)
        bbox = get_bbox(vertices)
        volume = compute_volume(vertices)
        return bbox, volume

    def check_stl(stl_path):
        bbox, volume = analyze_stl(stl_path)
        bbox_ok = 55 < (bbox['x'][1] - bbox['x'][0]) < 65 and \
                  25 < (bbox['y'][1] - bbox['y'][0]) < 35 and \
                  35 < (bbox['z'][1] - bbox['z'][0]) < 45
        volume_ok = 20000 < volume < 35000
        return {'bbox_ok': bbox_ok, 'volume_ok': volume_ok, 'volume': volume, 'bbox': bbox}

else:
    def analyze_stl(filepath):
        stl_mesh = mesh.Mesh.from_file(filepath)
        bbox = {
            'x': (stl_mesh.xmin, stl_mesh.xmax),
            'y': (stl_mesh.ymin, stl_mesh.ymax),
            'z': (stl_mesh.zmin, stl_mesh.zmax)
        }
        volume = stl_mesh.get_mass()
        return bbox, volume

    def check_stl(stl_path):
        bbox, volume = analyze_stl(stl_path)
        bbox_ok = 55 < (bbox['x'][1] - bbox['x'][0]) < 65 and \
                  25 < (bbox['y'][1] - bbox['y'][0]) < 35 and \
                  35 < (bbox['z'][1] - bbox['z'][0]) < 45
        volume_ok = 20000 < volume < 35000
        return {'bbox_ok': bbox_ok, 'volume_ok': volume_ok, 'volume': volume, 'bbox': bbox}

def main():
    stl_path = 'out/bracket.stl'
    
    if not os.path.exists(stl_path):
        print(f"Error: {stl_path} not found")
        sys.exit(1)
    
    result = check_stl(stl_path)
    
    os.makedirs('out', exist_ok=True)
    with open('out/check.json', 'w') as f:
        json.dump(result, f, indent=2)
    
    print(json.dumps(result, indent=2))
    
    if not (result['bbox_ok'] and result['volume_ok']):
        sys.exit(1)

if __name__ == '__main__':
    main()
